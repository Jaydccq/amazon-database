create view inventory_details
            (inventory_id, seller_id, seller_name, product_id, product_name, category_id, category_name, image,
             quantity, unit_price, created_at, updated_at, seller_rating)
as
SELECT i.inventory_id,
       i.seller_id,
       concat(a.first_name, ' ', a.last_name) AS seller_name,
       i.product_id,
       p.product_name,
       p.category_id,
       pc.category_name,
       p.image,
       i.quantity,
       i.unit_price,
       i.created_at,
       i.updated_at,
       COALESCE(avg(r.rating), 0::numeric)    AS seller_rating
FROM inventory i
         JOIN accounts a ON i.seller_id = a.user_id
         JOIN products p ON i.product_id = p.product_id
         JOIN products_categories pc ON p.category_id = pc.category_id
         LEFT JOIN reviews_feedbacks r ON i.seller_id = r.seller_id
GROUP BY i.inventory_id, a.first_name, a.last_name, p.product_name, p.category_id, pc.category_name, p.image;

alter table inventory_details
    owner to miniamazon;

