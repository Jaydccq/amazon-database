create view product_details
            (product_id, product_name, description, image, category_id, category_name, owner_id, owner_name, created_at,
             updated_at, average_rating, review_count)
as
SELECT p.product_id,
       p.product_name,
       p.description,
       p.image,
       p.category_id,
       pc.category_name,
       p.owner_id,
       concat(COALESCE(a.first_name, ''::character varying), ' ',
              COALESCE(a.last_name, ''::character varying)) AS owner_name,
       p.created_at,
       p.updated_at,
       COALESCE(avg(r.rating), 0::numeric)                  AS average_rating,
       count(r.review_id)                                   AS review_count
FROM products p
         JOIN products_categories pc ON p.category_id = pc.category_id
         JOIN accounts a ON p.owner_id = a.user_id
         LEFT JOIN reviews_feedbacks r ON p.product_id = r.product_id
GROUP BY p.product_id, pc.category_name, a.first_name, a.last_name;

alter table product_details
    owner to miniamazon;

